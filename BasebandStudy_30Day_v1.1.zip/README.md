# Baseband Study 1.1 — 30-day curriculum MVP

Samsung One UI inspired dark interface; Kotlin + Jetpack Compose.

## Included
- 30-day communication baseband curriculum, selectable day and lesson objective/topic
- Per-day completion state persisted locally; progress count and progress bar
- Fold inner screen responsive split layout (lesson list + detail); narrow screen single-column layout
- Daily alarm time setting, enable/disable, high-importance notification + vibration channel
- Alarm rescheduling after reboot/app replacement
- Default reminder 18:00; 2-hour study guidance

## Build
Open this folder in Android Studio, use JDK 17 and Android SDK 35, sync Gradle, then Build > Build APK(s).
Debug APK: app/build/outputs/apk/debug/app-debug.apk

## Samsung reliability
Grant notifications and (where offered) exact alarm access. Settings > Apps > Baseband Study > Battery: Unrestricted. Samsung battery/background policies can still affect delivery; test alarm on device.

## Curriculum
1 Passband/complex baseband; 2 sampling; 3 Fourier; 4 convolution/LTI; 5 random processes; 6 PSD/noise; 7 review; 8 modulation overview; 9 BPSK/QPSK; 10 QAM/Gray; 11 ML detection; 12 MAP; 13 matched filter; 14 BER; 15 receiver review; 16 Nyquist pulse shaping; 17 RRC; 18 timing recovery; 19 carrier sync/CFO; 20 channel estimation; 21 ZF/MMSE; 22 LMS; 23 OFDM; 24 cyclic prefix; 25 OFDM pilots; 26 coding basics; 27 LDPC/Polar/LLR; 28 5G NR PHY; 29 end-to-end receiver; 30 review & assessment.

This release provides curriculum index, topics/goals, and tracking. Lesson-specific long-form notes, quizzes, streak/calendar, widgets, and device-tested APK are planned enhancements. Reminder exactness depends on Android permission and device policy.
