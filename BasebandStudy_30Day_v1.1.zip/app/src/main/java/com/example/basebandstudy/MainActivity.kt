package com.example.basebandstudy

import android.app.*
import android.content.*
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import java.util.Calendar

private const val CHANNEL_ID = "study_reminder"
private const val PREFS = "baseband_prefs"

data class Lesson(val day:Int,val title:String,val topic:String,val goal:String,val key:String)
val lessons = listOf(
Lesson(1,"从 Passband 到 Complex Baseband","复包络、I/Q、解析信号","建立通带与复基带的数学映射","复基带"),
Lesson(2,"采样与离散时间基带","采样定理、过采样、符号率","理解连续信号如何变成数字序列","采样"),
Lesson(3,"傅里叶变换与频谱","CTFT/DTFT、频移、带宽","从时域和频域两种视角分析信号","傅里叶"),
Lesson(4,"卷积与 LTI 系统","冲激响应、卷积和、频域乘积","理解滤波器和信道对波形的作用","卷积"),
Lesson(5,"随机变量与随机过程","均值、方差、相关函数","建立噪声和随机信号分析基础","随机过程"),
Lesson(6,"功率谱密度与噪声","PSD、白噪声、带宽内噪声功率","理解噪声功率如何随带宽变化","PSD"),
Lesson(7,"第一周复盘与建模","复基带、采样、LTI、PSD","串联数学工具形成基带模型","复习"),
Lesson(8,"数字调制总览","ASK/PSK/QAM、星座图","理解符号映射和调制几何意义","调制"),
Lesson(9,"BPSK 与 QPSK","相位映射、距离、能量","从星座点理解误码性能","PSK"),
Lesson(10,"QAM 与 Gray 编码","16/64/256-QAM、比特映射","理解阶数、频谱效率与鲁棒性权衡","QAM"),
Lesson(11,"AWGN 与最优检测","似然函数、ML 判决","推导最小距离检测","ML检测"),
Lesson(12,"MAP 检测与先验概率","贝叶斯判决、先验概率","理解 MAP 与 ML 的差异","MAP"),
Lesson(13,"匹配滤波器","最大输出 SNR、充分统计量","推导匹配滤波器并理解接收机结构","匹配滤波"),
Lesson(14,"BER 与误码性能","Q 函数、Eb/N0、SER/BER","建立调制方式的性能比较方法","BER"),
Lesson(15,"第二周复盘：检测链路","映射、信道、滤波、判决","形成完整单载波接收链路图","复习"),
Lesson(16,"脉冲成形与 Nyquist","ISI、升余弦、滚降系数","理解频谱约束与无码间干扰条件","成形"),
Lesson(17,"根升余弦滤波器","RRC、Tx/Rx 匹配","理解发送与接收滤波器分工","RRC"),
Lesson(18,"符号定时恢复","眼图、Gardner、定时误差","理解采样时刻偏差及闭环校正","定时"),
Lesson(19,"载波频偏与相位同步","CFO、相位误差、PLL","理解频率/相位失配对星座的影响","同步"),
Lesson(20,"信道估计","导频、LS、插值","从已知训练符号估计信道","信道估计"),
Lesson(21,"线性均衡：ZF 与 MMSE","ISI、矩阵模型、噪声增强","比较 ZF 与 MMSE 的取舍","均衡"),
Lesson(22,"自适应均衡与 LMS","误差反馈、步长、收敛","理解自适应滤波器如何跟踪信道","LMS"),
Lesson(23,"OFDM 基础","子载波、IFFT/FFT、正交性","理解多载波如何简化频率选择性信道","OFDM"),
Lesson(24,"循环前缀与 OFDM 信道","CP、线性卷积变循环卷积","理解 CP 与频域单抽头均衡","循环前缀"),
Lesson(25,"OFDM 导频与信道估计","导频图样、二维插值","理解 OFDM 信道估计流程","导频"),
Lesson(26,"信道编码基础","码率、Hamming、卷积码","理解冗余如何换取可靠性","编码"),
Lesson(27,"现代编码与软信息","LDPC、Polar、LLR","理解软判决及现代编码框架","LDPC/Polar"),
Lesson(28,"5G NR 物理层概览","资源网格、RB、 numerology","把基带知识映射到 NR 术语","5G NR"),
Lesson(29,"端到端基带接收机串联","同步、估计、均衡、解调、译码","画出完整链路并解释模块输入输出","链路"),
Lesson(30,"综合复习与能力检验","知识地图、公式、工程问题","检验理论掌握并规划下一阶段","总复习")
)

class MainActivity : ComponentActivity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); createChannel()
 if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),100)
 setContent { BasebandApp(this) } }
 private fun createChannel(){ if(Build.VERSION.SDK_INT>=26){ val c=NotificationChannel(CHANNEL_ID,"学习提醒",NotificationManager.IMPORTANCE_HIGH).apply{description="每日通信基带学习提醒";enableVibration(true)};getSystemService(NotificationManager::class.java).createNotificationChannel(c)} }
}

@Composable fun BasebandApp(activity:Activity){
 val prefs=activity.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
 var hour by remember{mutableIntStateOf(prefs.getInt("hour",18))}; var minute by remember{mutableIntStateOf(prefs.getInt("minute",0))}
 var enabled by remember{mutableStateOf(prefs.getBoolean("enabled",true))}
 var selected by remember{mutableIntStateOf(1)}; var showTime by remember{mutableStateOf(false)}
 var refresh by remember{mutableIntStateOf(0)}
 val completed=remember(refresh){(1..30).filter{prefs.getBoolean("done_$it",false)}.toSet()}
 val teal=Color(0xFF00C7A2); val navy=Color(0xFF101820)
 MaterialTheme(colorScheme=darkColorScheme(primary=teal,background=navy,surface=Color(0xFF1B2730))){
 Scaffold(containerColor=navy){ padding->
 Row(Modifier.fillMaxSize().padding(padding).padding(12.dp),horizontalArrangement=Arrangement.spacedBy(12.dp)){
 // Fold inner screen: left lesson list, right detail. On narrow screen use single column.
 BoxWithConstraints(Modifier.fillMaxSize()){
 if(maxWidth>=600.dp){
 Column(Modifier.width(300.dp).fillMaxHeight()){
 Header(completed.size)
 LazyColumn(verticalArrangement=Arrangement.spacedBy(6.dp)){items(lessons){l->LessonRow(l,l.day in completed,selected==l.day){selected=l.day}}}
 }
 Spacer(Modifier.width(8.dp))
 Column(Modifier.weight(1f).fillMaxHeight()){Detail(activity,lessons[selected-1],selected in completed,{prefs.edit().putBoolean("done_$selected",it).apply();refresh++},hour,minute,enabled,{showTime=true},{enabled=it;prefs.edit().putBoolean("enabled",it).apply();scheduleReminder(activity,hour,minute,it)})}
 }else{
 Column(Modifier.fillMaxSize()){Header(completed.size); Detail(activity,lessons[selected-1],selected in completed,{prefs.edit().putBoolean("done_$selected",it).apply();refresh++},hour,minute,enabled,{showTime=true},{enabled=it;prefs.edit().putBoolean("enabled",it).apply();scheduleReminder(activity,hour,minute,it)})
 Spacer(Modifier.height(10.dp));Text("课程目录",color=Color.White);LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(5.dp)){items(lessons){l->LessonRow(l,l.day in completed,selected==l.day){selected=l.day}}}
 }
 }
 }
 }}
 }
 if(showTime){TimePickerDialog(activity,{_,h,m->hour=h;minute=m;prefs.edit().putInt("hour",h).putInt("minute",m).apply();scheduleReminder(activity,h,m,enabled);showTime=false},hour,minute,true).apply{setOnCancelListener{showTime=false}}.show()}
}

@Composable fun Header(done:Int){Column(verticalArrangement=Arrangement.spacedBy(4.dp)){Text("BASEBAND STUDY",color=Color(0xFF00C7A2),style=MaterialTheme.typography.labelLarge);Text("30 天通信基带训练",color=Color.White,style=MaterialTheme.typography.headlineSmall);Text("已完成 $done / 30 天",color=Color.LightGray);LinearProgressIndicator(progress={done/30f},modifier=Modifier.fillMaxWidth())}}
@Composable fun LessonRow(l:Lesson,done:Boolean,selected:Boolean,onClick:()->Unit){Card(Modifier.fillMaxWidth().clickable{onClick()},colors=CardDefaults.cardColors(containerColor=if(selected)Color(0xFF24433F) else Color(0xFF1B2730)),shape=RoundedCornerShape(12.dp)){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){Text(if(done)"✓" else "%02d".format(l.day),color=Color(0xFF00C7A2));Spacer(Modifier.width(10.dp));Column{Text(l.title,color=Color.White,style=MaterialTheme.typography.bodyMedium);Text(l.key,color=Color.LightGray,style=MaterialTheme.typography.labelSmall)}}}}
@Composable fun Detail(activity:Activity,l:Lesson,done:Boolean,onDone:(Boolean)->Unit,h:Int,m:Int,enabled:Boolean,onTime:()->Unit,onEnabled:(Boolean)->Unit){
 Column(Modifier.fillMaxWidth().padding(8.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
 Text("DAY %02d".format(l.day),color=Color(0xFF00C7A2));Text(l.title,color=Color.White,style=MaterialTheme.typography.headlineSmall);Text(l.topic,color=Color.LightGray)
 Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF1B2730))){Column(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("今日目标",color=Color(0xFF00C7A2));Text(l.goal,color=Color.White);Text("建议学习：理论推导 70 分钟 · 直觉与工程应用 30 分钟 · 练习 20 分钟",color=Color.LightGray)}}
 Button(onClick={onDone(!done)},modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.CheckCircle,null);Spacer(Modifier.width(8.dp));Text(if(done)"已完成 · 点击取消" else "完成第 ${l.day} 天打卡")}
 Divider();Text("每日提醒 · ${"%02d:%02d".format(h,m)}",color=Color.White);Row(verticalAlignment=Alignment.CenterVertically){Text("启用",color=Color.White);Spacer(Modifier.weight(1f));Switch(checked=enabled,onCheckedChange=onEnabled)};OutlinedButton(onClick=onTime,modifier=Modifier.fillMaxWidth()){Text("修改提醒时间")}
 Text("提醒内容：今天学习「${l.title}」并完成 2 小时训练。",color=Color.LightGray,style=MaterialTheme.typography.bodySmall)
 }
}

fun scheduleReminder(context:Context,hour:Int,minute:Int,enabled:Boolean){
 val am=context.getSystemService(Context.ALARM_SERVICE) as AlarmManager;val intent=Intent(context,ReminderReceiver::class.java)
 val pi=PendingIntent.getBroadcast(context,71,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);if(!enabled)return
 val c=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,hour);set(Calendar.MINUTE,minute);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)}
 try{if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.timeInMillis,pi)else am.setExact(AlarmManager.RTC_WAKEUP,c.timeInMillis,pi)}catch(_:SecurityException){am.set(AlarmManager.RTC_WAKEUP,c.timeInMillis,pi)}
}
class ReminderReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent?){val p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);val h=p.getInt("hour",18);val m=p.getInt("minute",0)
 val n=Notification.Builder(context,CHANNEL_ID).setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("通信基带学习时间到了").setContentText("今天学习「${lessons[(Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%30)].title}」— 开始 2 小时训练吧！").setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH).build()
 context.getSystemService(NotificationManager::class.java).notify(1001,n);scheduleReminder(context,h,m,true)}}
class BootReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent?){val p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE);scheduleReminder(context,p.getInt("hour",18),p.getInt("minute",0),p.getBoolean("enabled",true))}}
